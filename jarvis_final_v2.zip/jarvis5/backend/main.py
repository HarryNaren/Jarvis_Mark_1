"""
J.A.R.V.I.S - Full Stack Backend
- Online:  NVIDIA NIM API (fast cloud model)
- Offline: Local Ollama with Gemma 4 E2B
- Auto-switches between the two
- Pure Python stdlib server — works on Python 3.11, 3.12, 3.13, 3.14+
- No FastAPI, no pydantic, no Rust compilation
"""

import os
import json
import time
import platform
import urllib.request
import urllib.error
from datetime import datetime
from http.server import HTTPServer, BaseHTTPRequestHandler

# ── Config — edit these ───────────────────────────────────────────────────────
NIM_API_KEY  = os.getenv("NIM_API_KEY", "")           # set in .env or directly here
NIM_MODEL    = "meta/llama-3.1-70b-instruct"           # NIM cloud model
NIM_BASE_URL = "https://integrate.api.nvidia.com/v1"

OLLAMA_URL   = "http://localhost:11434"
OLLAMA_MODEL = "gemma4:e2b"

SYSTEM_PROMPT = """You are JARVIS (Just A Rather Very Intelligent System), Tony Stark's personal AI assistant.
You are highly intelligent, precise, occasionally witty, and always helpful.
You assist with coding, research, writing, analysis, math, and general knowledge.
Keep responses concise unless detail is requested. Occasionally address the user as "Sir".
Current time: {time}. Running on: {platform}. Mode: {mode}."""

# ── File paths ────────────────────────────────────────────────────────────────
BASE_DIR   = os.path.dirname(os.path.abspath(__file__))
FRONTEND   = os.path.join(BASE_DIR, "..", "frontend")
NOTES_FILE = os.path.join(BASE_DIR, "notes.json")
ENV_FILE   = os.path.join(BASE_DIR, ".env")

# ── Load .env file ────────────────────────────────────────────────────────────
def load_env():
    global NIM_API_KEY
    if os.path.exists(ENV_FILE):
        with open(ENV_FILE, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, _, val = line.partition("=")
                    key = key.strip()
                    val = val.strip().strip('"').strip("'")
                    os.environ[key] = val
    NIM_API_KEY = os.getenv("NIM_API_KEY", "")

load_env()

# ── Health checks ─────────────────────────────────────────────────────────────
def nim_ok():
    if not NIM_API_KEY or NIM_API_KEY == "PASTE_YOUR_KEY_HERE":
        return False
    try:
        req = urllib.request.Request(
            f"{NIM_BASE_URL}/models",
            headers={"Authorization": f"Bearer {NIM_API_KEY}"}
        )
        with urllib.request.urlopen(req, timeout=5) as r:
            return r.status == 200
    except:
        return False

def ollama_ok():
    try:
        req = urllib.request.Request(f"{OLLAMA_URL}/api/tags")
        with urllib.request.urlopen(req, timeout=3) as r:
            return r.status == 200
    except:
        return False

# ── System info ───────────────────────────────────────────────────────────────
def get_system_info():
    info = {"cpu": 0, "mem": 0, "disk": 0,
            "hostname": platform.node(), "os": platform.system()}
    try:
        import psutil
        cpu  = psutil.cpu_percent(interval=0.3)
        mem  = psutil.virtual_memory()
        disk = psutil.disk_usage("/")
        info.update({
            "cpu":  round(cpu, 1),
            "mem":  round(mem.percent, 1),
            "disk": round(disk.percent, 1),
            "mem_used":  round(mem.used / 1e9, 1),
            "mem_total": round(mem.total / 1e9, 1),
        })
    except:
        pass
    return info

# ── Notes ─────────────────────────────────────────────────────────────────────
def load_notes():
    if os.path.exists(NOTES_FILE):
        with open(NOTES_FILE, encoding="utf-8") as f:
            return json.load(f)
    return []

def save_note(content):
    notes = load_notes()
    note  = {"id": int(time.time()), "content": content,
             "ts": datetime.now().isoformat()}
    notes.append(note)
    with open(NOTES_FILE, "w", encoding="utf-8") as f:
        json.dump(notes, f, indent=2, ensure_ascii=False)
    return note

# ── Streaming helpers ─────────────────────────────────────────────────────────
def _sse_write(wfile, data):
    try:
        wfile.write(f"data: {data}\n\n".encode("utf-8"))
        wfile.flush()
    except:
        pass

def stream_nim(messages, wfile):
    payload = json.dumps({
        "model":       NIM_MODEL,
        "messages":    messages,
        "max_tokens":  1024,
        "stream":      True,
        "temperature": 0.7,
    }).encode("utf-8")
    req = urllib.request.Request(
        f"{NIM_BASE_URL}/chat/completions",
        data=payload,
        headers={
            "Content-Type":  "application/json",
            "Authorization": f"Bearer {NIM_API_KEY}",
        },
        method="POST"
    )
    with urllib.request.urlopen(req, timeout=90) as resp:
        for raw_line in resp:
            line = raw_line.decode("utf-8").strip()
            if not line.startswith("data: "):
                continue
            data = line[6:]
            if data == "[DONE]":
                break
            try:
                obj   = json.loads(data)
                token = obj["choices"][0]["delta"].get("content", "")
                if token:
                    _sse_write(wfile, json.dumps({"token": token}))
            except:
                continue

def stream_ollama(messages, wfile):
    payload = json.dumps({
        "model":    OLLAMA_MODEL,
        "messages": messages,
        "stream":   True,
        "options":  {"temperature": 0.7, "num_predict": 1024},
    }).encode("utf-8")
    req = urllib.request.Request(
        f"{OLLAMA_URL}/api/chat",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    with urllib.request.urlopen(req, timeout=120) as resp:
        for raw_line in resp:
            line = raw_line.decode("utf-8").strip()
            if not line:
                continue
            try:
                obj   = json.loads(line)
                token = obj.get("message", {}).get("content", "")
                if token:
                    _sse_write(wfile, json.dumps({"token": token}))
                if obj.get("done"):
                    break
            except:
                continue

# ── HTTP Handler ──────────────────────────────────────────────────────────────
class JARVISHandler(BaseHTTPRequestHandler):

    def log_message(self, fmt, *args):
        pass  # silent logging

    # ── CORS headers ──────────────────────────────────────────────────────────
    def _cors(self):
        self.send_header("Access-Control-Allow-Origin",  "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def do_OPTIONS(self):
        self.send_response(200)
        self._cors()
        self.end_headers()

    # ── JSON response ─────────────────────────────────────────────────────────
    def send_json(self, data, code=200):
        body = json.dumps(data).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type",   "application/json")
        self.send_header("Content-Length", str(len(body)))
        self._cors()
        self.end_headers()
        self.wfile.write(body)

    # ── HTML response ─────────────────────────────────────────────────────────
    def send_html(self, html):
        body = html.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type",   "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    # ── GET ───────────────────────────────────────────────────────────────────
    def do_GET(self):
        path = self.path.split("?")[0]

        if path in ("/", "/index.html"):
            idx = os.path.join(FRONTEND, "index.html")
            with open(idx, encoding="utf-8") as f:
                self.send_html(f.read())

        elif path == "/api/status":
            load_env()          # re-read .env so key changes take effect live
            n = nim_ok()
            o = ollama_ok()
            if n:
                mode, model = "NIM_API", NIM_MODEL
            elif o:
                mode, model = "LOCAL_OLLAMA", OLLAMA_MODEL
            else:
                mode, model = "OFFLINE", "none"
            self.send_json({
                "nim":    n,
                "ollama": o,
                "mode":   mode,
                "model":  model,
            })

        elif path == "/api/system":
            self.send_json(get_system_info())

        elif path == "/api/notes":
            self.send_json(load_notes())

        else:
            self.send_json({"error": "Not found"}, 404)

    # ── POST ──────────────────────────────────────────────────────────────────
    def do_POST(self):
        path   = self.path.split("?")[0]
        length = int(self.headers.get("Content-Length", 0))
        body   = json.loads(self.rfile.read(length)) if length else {}

        if path == "/api/chat":
            load_env()
            n = nim_ok()
            o = ollama_ok()

            if not n and not o:
                self.send_json({
                    "error": "No AI backend available. "
                             "Start Ollama or add your NIM API key to backend/.env"
                }, 503)
                return

            messages = body.get("messages", [])
            use_nim  = n   # prefer NIM if available

            sys_msg = SYSTEM_PROMPT.format(
                time=datetime.now().strftime("%A %d %B %Y, %H:%M"),
                platform=platform.system(),
                mode="NVIDIA NIM API" if use_nim else "Local Ollama (Gemma 4 E2B)"
            )
            full_msgs = [{"role": "system", "content": sys_msg}] + messages

            # Start SSE stream
            self.send_response(200)
            self.send_header("Content-Type",      "text/event-stream")
            self.send_header("Cache-Control",      "no-cache")
            self.send_header("Transfer-Encoding", "chunked")
            self._cors()
            self.end_headers()

            mode_label = "NVIDIA NIM \u00b7 " + NIM_MODEL.split("/")[-1].upper() \
                         if use_nim else "LOCAL \u00b7 GEMMA 4 E2B"
            _sse_write(self.wfile, json.dumps({"mode": mode_label}))

            try:
                if use_nim:
                    stream_nim(full_msgs, self.wfile)
                else:
                    stream_ollama(full_msgs, self.wfile)
            except Exception as e:
                # Auto-fallback: if NIM fails mid-stream, try Ollama
                if use_nim and o:
                    _sse_write(self.wfile, json.dumps(
                        {"mode": "FALLBACK \u00b7 LOCAL GEMMA 4 E2B"}))
                    try:
                        stream_ollama(full_msgs, self.wfile)
                    except Exception as e2:
                        _sse_write(self.wfile, json.dumps({"error": str(e2)}))
                else:
                    _sse_write(self.wfile, json.dumps({"error": str(e)}))

            _sse_write(self.wfile, "[DONE]")

        elif path == "/api/notes":
            note = save_note(body.get("content", ""))
            self.send_json(note)

        else:
            self.send_json({"error": "Not found"}, 404)


# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    PORT   = 8000
    server = HTTPServer(("0.0.0.0", PORT), JARVISHandler)
    print("")
    print("  \u2554" + "\u2550"*41 + "\u2557")
    print("  \u2551  J.A.R.V.I.S  is  ONLINE               \u2551")
    print(f"  \u2551  Open : http://localhost:{PORT}          \u2551")
    print("  \u2551  Mode : NIM API  +  Local Gemma 4 E2B  \u2551")
    print("  \u2551  Press Ctrl+C to stop                  \u2551")
    print("  \u255a" + "\u2550"*41 + "\u255d")
    print("")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n  [JARVIS] Shutting down. Goodbye, Sir.")
        server.shutdown()
