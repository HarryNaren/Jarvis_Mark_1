@echo off
cd /d "%~dp0backend"

echo.
echo   ============================================
echo    J.A.R.V.I.S  --  STARK INDUSTRIES
echo    NIM API + Local Gemma 4 E2B
echo    Python 3.14 Compatible
echo   ============================================
echo.

REM Check Python exists
python --version >nul 2>&1
if errorlevel 1 (
  echo   [ERROR] Python not found!
  echo   Install from https://python.org
  echo   Check "Add python.exe to PATH" during install
  pause
  exit /b 1
)

echo   [*] Python version:
python --version

echo   [*] Installing psutil...
python -m pip install psutil==6.1.1 --quiet --disable-pip-version-check

echo.
echo   [OK] Starting JARVIS...
echo   [OK] Open browser: http://localhost:8000
echo   [OK] Ctrl+C to stop
echo.

python main.py
pause
