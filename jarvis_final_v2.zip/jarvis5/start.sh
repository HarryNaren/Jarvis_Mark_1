#!/bin/bash
cd "$(dirname "$0")/backend"

echo ""
echo "  ============================================"
echo "   J.A.R.V.I.S  --  STARK INDUSTRIES"
echo "   NIM API + Local Gemma 4 E2B"
echo "  ============================================"
echo ""

python3 --version >/dev/null 2>&1 || { echo "[ERROR] Python3 not found"; exit 1; }
python3 -m pip install psutil==6.1.1 --quiet

echo ""
echo "  [OK] Open browser: http://localhost:8000"
echo "  [OK] Ctrl+C to stop"
echo ""

python3 main.py
